import 'package:flutter/material.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

// ----- REPOSITORY (database code is here) -----
class TaskRepository {
  late Database db;

  // open database and create table
  Future<void> init() async {
    final path = join(await getDatabasesPath(), 'tasks.db');
    db = await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE tasks ('
          'id INTEGER PRIMARY KEY AUTOINCREMENT, '
          'title TEXT NOT NULL, '
          'is_completed INTEGER NOT NULL DEFAULT 0)',
        );
      },
    );
  }

  // Create
  Future<int> create(String title) {
    return db.insert('tasks', {'title': title});
  }

  // Read
  Future<List<Map<String, Object?>>> getAll() {
    return db.query('tasks', orderBy: 'id DESC');
  }

  // Update
  Future<int> markCompleted(int id) {
    return db.update(
      'tasks',
      {'is_completed': 1},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // Delete
  Future<int> delete(int id) {
    return db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }
}

// ----- MAIN -----
final repository = TaskRepository();

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await repository.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: TaskScreen(),
    );
  }
}

// ----- SCREEN (UI only) -----
class TaskScreen extends StatefulWidget {
  const TaskScreen({super.key});

  @override
  State<TaskScreen> createState() => _TaskScreenState();
}

class _TaskScreenState extends State<TaskScreen> {
  final controller = TextEditingController();
  List<Map<String, Object?>> tasks = [];

  @override
  void initState() {
    super.initState();
    loadTasks();
  }

  void showMessage(String text) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  // get tasks from database and show them
  Future<void> loadTasks() async {
    try {
      final data = await repository.getAll();
      setState(() => tasks = data);
    } catch (e) {
      showMessage('Could not load tasks');
    }
  }

  Future<void> addTask() async {
    final title = controller.text.trim();

    // validation: no empty or spaces-only title
    if (title.isEmpty) {
      showMessage('Please enter a task title');
      return;
    }

    try {
      await repository.create(title);
      controller.clear();
      await loadTasks();
    } catch (e) {
      showMessage('Could not add task');
    }
  }

  Future<void> completeTask(int id) async {
    try {
      await repository.markCompleted(id);
      await loadTasks();
    } catch (e) {
      showMessage('Could not update task');
    }
  }

  Future<void> deleteTask(int id) async {
    try {
      await repository.delete(id);
      await loadTasks();
    } catch (e) {
      showMessage('Could not delete task');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Task Manager')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: controller,
                    decoration: const InputDecoration(hintText: 'Task title'),
                  ),
                ),
                ElevatedButton(onPressed: addTask, child: const Text('Add')),
              ],
            ),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, index) {
                  final task = tasks[index];
                  final id = task['id'] as int;
                  final done = task['is_completed'] == 1;

                  return ListTile(
                    leading: Checkbox(
                      value: done,
                      onChanged: done ? null : (_) => completeTask(id),
                    ),
                    title: Text(
                      task['title'] as String,
                      style: TextStyle(
                        decoration: done ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () => deleteTask(id),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
