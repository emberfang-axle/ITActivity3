# State Management App

A simple Flutter app that shows how state management works using `setState`.
The app has a counter that changes when the user taps a button.

## Features
- Increase the counter with the green + button
- Decrease the counter with the red - button (it cannot go below 0)
- Reset the counter to 0 with the grey refresh button
- The number is grey when it is 0 and purple when it is higher
- The message changes from "Tap a button to get started" to "Keep counting!"

## How it works
- `CounterScreen` is a `StatefulWidget`
- The counter value is stored in the variable `_counter`
- Each button calls `setState()` so the screen updates right away

## Note
The counter is stored only in memory, so it goes back to 0 when the app is closed and opened again.

## How to run
1. Run `flutter pub get`
2. Run `flutter run`

## Reflection
See [reflection.md](activity3/reflection.md)